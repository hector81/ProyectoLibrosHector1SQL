<?php ob_start(); include './app/config/nl2br2.php'; ?>





<?php $contenido = ob_get_clean() ?>
<?php include 'baseInicio.php' ?>
